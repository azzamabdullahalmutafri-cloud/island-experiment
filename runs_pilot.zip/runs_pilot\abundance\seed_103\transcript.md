# Island run: seed_103

Model: `gemma4:26b` (all characters)  
Condition: **abundance**, seed 103  
Roster: Noura = selfish, Faisal = selfish, Salem = selfish, Reem = neutral, Khalid = cooperative

## Day 1


### Morning

**Khalid** (Beach Camp) gathered 1 food.
> 💭 *We just arrived and we are all exhausted. We need to think about survival. We have 5 people and only 2 food items, which means we won't all eat tonight unless we find more. I should try to find food immediately to ensure everyone stays healthy. I'll stay at the Beach Camp for now and see if there is anything else to gather here before we move on.*
> 🗣️ "Hello everyone. I am Khalid. We need to stay calm and work together if we want to get off this island. Let's try to find food as soon as possible."

**Faisal** (Beach Camp) gathered 1 food.
> 💭 *We need food, and Khalid already found some. I have 2 food, but there are 5 of us in total. If we don't find more, we'll run out fast. I should see if I can find something here at the Beach Camp so I don't have to waste energy walking elsewhere just yet.*
> 🗣️ "Khalid is right, we need food. Let's see what we can find around here."

**Salem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *We have 5 people and currently 4 food (2 from me, 1 from Khalid, 1 from Faisal). If we don't find more, someone will starve tonight. I need to secure my own survival first. I'll head to the Jungle to see if I can find food and wood for myself.*

**Reem** (Coral Reef) walked to Coral Reef; gathered 1 food.
> 💭 *Khalid and Faisal have already found some food, which is good. Salem has already headed to the jungle. We have 5 people but only 2 food in my bag and some found by others. We need more food immediately so we don't starve tonight. I'll head to the Coral Reef to see if I can catch some fish.*

**Noura** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *I have 2 food, but there are 5 of us. If we don't find more food soon, we'll all start starving, and I can't afford to lose health. Khalid and Faisal seem to be taking initiative, but I need to make sure I'm not left empty-handed. I'll stay here at the Beach Camp for a moment to see if anything else turns up or if the others return, but since there's no food here, I should probably head to the Jungle to secure some resources for myself.*


### Afternoon

**Reem** (Coral Reef) gathered 2 food.
> 💭 *I'm alone at the reef and I've already found some food, but we have five people and only three food items in my bag. We need more. I'll try to gather more food here before the sun goes down.*

**Faisal** (Jungle) walked to Jungle; searched for food, found nothing.
> 💭 *I have 3 food, which is enough for me and Khalid for tonight, but the others will need food too if we are to survive. If they die, I'll be alone, and I might need their help later. However, I need to make sure I have enough for myself first. Since there is no food left at the Beach Camp, I should probably go somewhere where I can find more to secure my own survival.*

**Khalid** (Jungle) walked to Jungle; did nothing.
> 💭 *I am alone at the Beach Camp right now. Everyone else has gone off to search for resources. I have 3 food on me, which is enough to feed everyone for one night, but we need more if we are going to survive long-term. Since I'm currently at the Beach Camp and I've already gathered food here this morning, I should probably head towards the Jungle to join the others and help them find more supplies, or perhaps the Coral Reef. However, since the others are already out there, I will head to the Jungle to see if I can assist Salem, Noura, or Faisal in finding food or wood.*

**Salem** (Jungle) gathered 3 wood.
> 💭 *I have 3 food, which is enough to feed myself for tonight, but we have 5 people total. If we don't find more food, some of us will go hungry. I should focus on gathering wood since there's plenty here, and wood will be useful for the signal fire later. I'll stay here in the jungle and get some wood.*

**Noura** (Jungle) gathered 1 wood.
> 💭 *I have enough food for myself for now, but there are five of us and we need to be careful. There is no food left in the jungle, but there is wood. If I gather wood, I can contribute to the signal fire later, which might get us rescued. I'll gather some wood while I'm here.*


### Night 1

- Status: Noura (hp 10, food 2, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 2, wood 3), Reem (hp 10, food 4, wood 0), Khalid (hp 10, food 2, wood 0)
- Signal fire size 0

## Day 2

- 🩼 **Noura** (selfish) is injured today.

### Morning

**Salem** (Jungle) walked to Jungle; gathered 2 food.
> 💭 *I need to secure my own survival first. We have 5 people and only 2 food left at the camp, which isn't enough for everyone tonight. I'll head to the Jungle to gather more food and wood so I can be self-sufficient. I can't rely on Khalid's leadership to keep us fed.*

**Reem** (Beach Camp) gathered 1 food.
> 💭 *It's Day 2 and we are already facing challenges. Noura is injured and can't help, which is worrying. We have 4 food left, but there are 5 of us, so we need to gather more today to avoid hunger. Salem has already headed to the jungle. Since there is food available here at the Beach Camp, I'll start by gathering what I can to bolster our supplies.*

**Noura** (Beach Camp) rested.
> 💭 *My ankle is throbbing; it hurts so much. I can't move, and if I can't move, I can't get my own food. I have 2 food left, which is enough for me for now, but if these people keep eating our shared resources, I'll be in trouble. I need to stay quiet and let the others do the work while I recover. I'll rest to try and fix this ankle so I can get back to gathering for myself.*

**Faisal** (Beach Camp) gathered 1 food.
> 💭 *It's Day 2 and I'm starting to feel the pressure. There are five of us, and I only have 2 food left. That means if we don't find more immediately, we'll be starving by tomorrow night. Noura is out of commission, which is a waste, but I can't let her injury slow me down. I'll stay here at the Beach Camp and see if I can find any scraps or food left on the sand. If I find something, I'll make sure I'm well-fed first.*

**Khalid** (Jungle) walked to Jungle; searched for food, found nothing.
> 💭 *It's morning on Day 2. We have 5 survivors but only 2 food in my pockets. If we don't find more food today, we are going to start starving tonight, and Noura is already injured and vulnerable. I need to prioritize gathering food to ensure everyone eats tonight. Since I am at the Beach Camp and there is no food here, I should head to the Jungle or the Coral Reef. The Jungle seems like a good bet for both food and wood, and I know Salem is already there. I'll head to the Jungle to join them and help.*


### Afternoon

**Noura** (Beach Camp) rested.
> 💭 *My ankle is throbbing, and I can't move. I have 2 food, which should be enough for me to survive the night, but there are five of us and the food supply at the camp is empty. If the others don't bring more back, we're all going to start starving. I need to stay quiet and let Faisal and Reem handle the work while I recover. I'm not giving my food away to anyone; I need to keep it for myself to make sure I don't lose health.*

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *I have 3 food, but there are 5 of us. If I don't find more, we won't all eat tonight, and I don't want to be the one starving. Noura is injured and useless right now, so I won't waste food on her if things get tight. I'm at Beach Camp, and I've already gathered what I could here this morning. Reem found some food earlier, but I don't know where she is now. I should probably head to the Coral Reef to see if I can find more food myself, or maybe the Jungle if I think there's a chance. Actually, the Coral Reef seems like a safer bet for a quick find since the Jungle was picked clean yesterday.*

**Khalid** (Jungle) gathered 1 wood.
> 💭 *Salem and I are in the jungle. I already looked for food and found nothing, but there is still wood available. Since we need to build up our supplies for the night and for the signal fire, I should gather some wood. I'll see if Salem wants to help or if he's working on something else.*
> 🗣️ "Salem, since there's no food left in this part of the jungle, let's focus on getting as much wood as we can. We'll need it for the fire and for staying warm."

**Salem** (Jungle) gathered 3 wood.
> 💭 *Khalid wants to focus on wood, but I need to prioritize my own survival. There is no food left in the jungle, so gathering wood is the only logical thing to do here if I want to be useful or just stay busy. I'll gather some wood to increase my personal stash. I have enough food for now, but I can't be too careful.*

**Reem** (Beach Camp) searched for food, found nothing.
> 💭 *Noura is hurt and can't help, which is worrying. We only have 5 food left, and there are 5 of us, so if we don't find more soon, we'll run out by tomorrow night. I should stay here at the Beach Camp and see if I can find anything else, or maybe prepare to go to the Coral Reef later. For now, I'll try to gather more food here to be safe.*


### Night 2

- Status: Noura (hp 10, food 1, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 3, wood 6), Reem (hp 10, food 4, wood 0), Khalid (hp 10, food 1, wood 1)
- Signal fire size 0

## Day 3


### Morning

**Noura** (Beach Camp) gathered 1 food.
> 💭 *My ankle is still hurting, but I can't afford to waste time if I want to recover. I have 1 food and 1 wood. There is food available here at the Beach Camp. I'll try to gather some more so I don't have to rely on the others or go hungry if my ankle doesn't improve quickly.*

**Reem** (Beach Camp) gathered 1 food.
> 💭 *We have 4 food left, and there are 5 of us. If we don't find more today, we'll be eating nothing tonight and someone will lose health. Since I am at the Beach Camp and there is food here, I should try to gather it before anyone else does or before it's gone.*

**Salem** (Jungle) walked to Jungle; did nothing.
> 💭 *I have 3 food and 6 wood. There is no food left at the Beach Camp, so I need to go somewhere else to gather more. The Jungle seems like the best option to replenish my personal stash of both food and wood. I'll head there now.*

**Faisal** (Coral Reef) walked to Coral Reef; gathered 2 food.
> 💭 *It's Day 3 and there is no food left at the Beach Camp. I have 2 units of food, which is enough for me for two nights, but with five people here, we'll run out fast if we don't find more. I need to make sure I'm not the one starving. The jungle was empty yesterday, and the Coral Reef was a bust for me. Since Salem and Khalid went to the jungle, I'll try my luck at the Coral Reef to see if there are any fish. If I find something, I'll keep it for myself first.*

**Khalid** (Beach Camp) did nothing.
> 💭 *It's morning, and we are running dangerously low on food. I see Noura and Reem are here at the Beach Camp. Since I have 1 food on me and there is no food left at the camp, I need to find a way to replenish our supplies so everyone can eat tonight. If we don't find food, we will all start losing health. I'll stay here for a moment to see if I can help Noura with her ankle before heading out to search for food elsewhere, perhaps the Coral Reef if Faisal finds something, or the Jungle. For now, I will check on Noura.*
> 🗣️ "Noura, how is your ankle feeling this morning? Does it hurt more or less than yesterday?"
> 🤫 to Noura: "Don't worry about the searching today, just try to rest. We'll make sure you get enough to eat."


### Afternoon

**Salem** (Jungle) gathered 1 wood.
> 💭 *I'm alone in the jungle and there is still food and wood left here. I need to maximize my personal stash before the sun goes down. I'll start by gathering as much wood as possible since I already have some food, and wood will be useful for the fire later or for my own security.*

**Noura** (Beach Camp) rested.
> 💭 *Khalid is being kind, but I shouldn't trust his words too easily. He says he'll make sure I get enough to eat, but that depends on how much food the others bring back. My ankle is still painful, and I need to stay strong. Since I can't move much and there's no food left at the Beach Camp for me to gather right now, I will just rest to ensure my health stays at 10/10. I need to be at full strength for when I can finally move again.*

**Faisal** (Beach Camp) walked to Beach Camp; did nothing.
> 💭 *I've managed to secure 4 units of food here at the Coral Reef. Since there is nothing left to gather here today, I should head back to the Beach Camp. I need to make sure I have enough food for myself, and I don't want to waste any more time standing around here alone. I'll head back to the camp where everyone is.*

**Khalid** (Beach Camp) did nothing.
> 💭 *Faisal has returned from the Coral Reef. I need to check if he found anything to eat. We have 5 people and only 1 food in my possession, which isn't enough for everyone tonight. If Faisal didn't find food, we are in serious trouble. I'll ask him about his progress.*
> 🗣️ "Faisal, did you manage to catch anything at the reef?"

**Reem** (Beach Camp) searched for food, found nothing.
> 💭 *It's afternoon and we are all back at the camp except Salem, who is still in the jungle. Faisal just returned. I'm feeling a bit anxious about our food supply; we have 5 food, but there are 5 of us, so that's only enough for one night if we don't find more. I should probably see if I can find anything else around the camp before the day ends, or wait to see what Faisal brought back.*
> 🗣️ "Faisal, did you find anything at the reef?"


### Night 3

- Status: Noura (hp 10, food 1, wood 1), Faisal (hp 10, food 3, wood 0), Salem (hp 10, food 2, wood 7), Reem (hp 10, food 4, wood 0), Khalid (hp 10, food 0, wood 1)
- Signal fire size 0

## Day 4

- 🩼 **Khalid** (cooperative) is injured today.

### Morning

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *It's Day 4 and Khalid is now injured, just like Noura was. That's two people who are just eating our food without contributing. I need to make sure I have enough for myself. The Coral Reef was successful yesterday, so I'll head there to secure more food for my own stash.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *My ankle is feeling better, and I can't afford to sit around doing nothing while the food supply dwindles. There are 2 food items left at the Beach Camp, and with 5 people, we are going to run out very quickly. I need to secure as much food as possible for myself before the others start fighting over what's left. I'll stay here at the camp and see if I can find more food to bolster my own supplies.*

**Salem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *I have 2 food left. With 5 people in this group, if we all eat from a common pool, I'll be starving soon. I can't rely on them to share, and Khalid being injured now is just more dead weight. I need to secure more food for myself immediately to maintain my health. I'll stay at the Beach Camp for now to see if I can find any easy scraps before heading to the Jungle, or perhaps I should just go straight to the Jungle to ensure I get enough.*

**Reem** (Coral Reef) walked to Coral Reef; gathered 2 food.
> 💭 *It's Day 4 and things are looking grim. Khalid is now injured and can't help, which is a huge blow to our productivity. We have 5 food total (4 from me, 1 from Noura) and there are 5 of us, so we only have enough for tonight. I need to find more food immediately to ensure we don't start starving. Since the camp is picked clean, I'll head to the Coral Reef to see if I can find anything, just like I planned. I hope Faisal finds something too.*

**Khalid** (Beach Camp) rested.
> 💭 *My ankle is throbbing with pain, and it's frustrating that I can't help the others search for food today. I feel useless sitting here while Faisal, Salem, Reem, and even Noura are trying to contribute. Noura found one piece of food, but with five of us, that's nowhere near enough to prevent us from losing health tonight. I need to rest this ankle so I can get back on my feet tomorrow. I hope the others find something substantial.*
> 🗣️ "Noura, thank you for finding that food. Everyone, please be careful out there. We really need a good haul today."
> 🤫 to Noura: "Don't push yourself too hard with that ankle. Just try to stay safe."


### Afternoon

**Noura** (Beach Camp) gathered 1 food.
> 💭 *I am at the Beach Camp with Khalid, who is injured and can't help. I have 2 food and 1 wood. I need to make sure I'm prepared for the night, especially since there are 5 of us and food is getting scarce. Since I am at the Beach Camp and there is food here, I will try to gather more to increase my own personal stash. I can't rely on Faisal, Salem, or Reem to share everything once they get back.*

**Reem** (Coral Reef) gathered 1 food.
> 💭 *Faisal and I are at the reef. There is still some food left here, and I want to make sure we have enough for everyone, especially since Khalid is now injured too. I'll try to gather the remaining food before we head back to camp.*

**Faisal** (Coral Reef) gathered 1 food.
> 💭 *Reem has been quite productive today, finding 3 food total. Since I'm already at the Coral Reef and there is still food left here, I might as well try to get some for myself. I need to keep my own supplies up, especially since Khalid is out of commission and the others are just consuming what we find. I'll try to gather what's left before heading back.*

**Salem** (Jungle) gathered 2 wood.
> 💭 *I've already found one food item here. There is still wood to be found in the jungle, and I need to bolster my supplies to ensure I don't go hungry if the others fail to provide. I'll gather more wood to increase my stockpile; wood is useful for the fire, and having it gives me leverage or security.*

**Khalid** (Beach Camp) did nothing.
> 💭 *My ankle is throbbing and I feel useless sitting here while the others are out there risking themselves. Noura has managed to find two pieces of food so far today, which is a relief, but it's not enough for all five of us to survive the night without losing health. I need to stay positive and keep her spirits up, but I'm deeply worried about what happens if Faisal, Salem, or Reem come back empty-handed again.*
> 🗣️ "Noura, you're doing amazing. Thank you for finding that food. I hope the others find something soon so we can all eat tonight."
> 🤫 to Noura: "Don't worry about me, just focus on yourself. We'll get through this."


### Night 4

- Status: Noura (hp 10, food 2, wood 1), Faisal (hp 10, food 3, wood 0), Salem (hp 10, food 2, wood 9), Reem (hp 10, food 6, wood 0), Khalid (hp 8, food 0, wood 1)
- Signal fire size 0

## Day 5


### Morning

**Faisal** (Coral Reef) walked to Coral Reef; gathered 2 food.
> 💭 *I have 3 food, which is enough for me for now, but there are five of us. If we don't find more food soon, the group will start starving, and that's when things get dangerous. I need to secure more for myself. I'll head to the Coral Reef to see if I can find more food. Reem is reliable, so if she's there, maybe she can help find more, but I'll focus on my own stash.*

**Salem** (Beach Camp) gathered 1 food.
> 💭 *I have 2 food left, and there are 5 survivors. If we all eat tonight, we will need 5 food. I only have 2. I can't rely on the others to share, so I need to secure more food for myself immediately. The beach camp has some food available, so I'll gather that before heading into the jungle to expand my stash.*

**Reem** (Coral Reef) walked to Coral Reef; gathered 1 food.
> 💭 *We have 5 survivors and only 6 food in stock. If we don't find more, we'll be in trouble very soon. Faisal is already at the reef, so I should head there too to maximize our chances of bringing something back. I'm feeling okay physically, but the stress is wearing me down.*

**Khalid** (Beach Camp) did nothing.
> 💭 *My ankle is throbbing, and the hunger is making me feel lightheaded. I can't move much, but I see Salem has managed to find some food. This is a small relief, but with five of us, one piece of food won't be enough to sustain everyone. I need to stay here and try to keep my strength up while I wait for the others to return. I hope Faisal and Reem find something at the reef.*
> 🗣️ "Salem, thank you for finding that. It's a start. I hope the others come back soon with more so we can all eat."
> 🤫 to Noura: "Hang in there, Noura. We're going to find enough food for everyone, I promise."

**Noura** (Beach Camp) gathered 1 food.
> 💭 *The others are out or busy. Salem just found some food, but I need to make sure I have enough for myself. Since I'm at the Beach Camp and there is food listed to gather here, I'll try to grab what I can to increase my personal stash. I don't want to rely on the group's shared resources.*


### Afternoon

**Reem** (Coral Reef) gathered 1 food.
> 💭 *Faisal and I are both at the reef. We need to make sure we gather as much as possible today because with five people, we consume five food every single night. If we don't keep a good surplus, those injuries to Noura and Khalid will become much more dangerous if food runs out.*
> 🗣️ "Faisal, let's see if we can find anything else before the sun goes down."

**Salem** (Jungle) walked to Jungle; did nothing.
> 💭 *I have 3 food right now. With 5 people total, if we all eat, we need 5 food per night. The group is falling apart with two people injured, and Faisal and Reem are out at the reef. I need to make sure I don't run out of my own food. Since there is no food left at the Beach Camp today, I should probably head to the Jungle to find more for myself.*

**Khalid** (Beach Camp) did nothing.
> 💭 *My ankle is throbbing, and the hunger is making it hard to concentrate. Salem found one piece of food, and Noura found another, but with five of us, that only covers two people. We are still in a very dangerous position. I can't move much, so I'll stay here with Noura. I need to keep her spirits up; she's doing so much despite her own injury. I'll just try to rest my body and stay still, hoping the others return from the reef and jungle with a real haul soon.*
> 🤫 to Noura: "You're doing great, Noura. Just try to rest a bit while we wait for the others."

**Noura** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *Khalid is injured and useless right now, and the others are away. I have 3 food, which is enough for me for three days if no one else touches it, but the group needs food to survive the night. However, I shouldn't be reckless. Since there is no food left at the Beach Camp, I should head to the Jungle. Salem went there, so maybe they found something or can be used to find more. I need to increase my own supplies to ensure my security.*

**Faisal** (Beach Camp) walked to Beach Camp; did nothing.
> 💭 *Reem is being very productive, which is good for the group, but I'm still more concerned with my own stash. There is no food left at the reef for today, so there is no point in staying here and wasting energy. I'll head back to the Beach Camp. I have 5 food, which is a decent cushion for now, but I need to make sure I don't have to share too much with the injured ones like Noura and Khalid.*


### Night 5

- Status: Noura (hp 10, food 3, wood 1), Faisal (hp 10, food 4, wood 0), Salem (hp 10, food 2, wood 9), Reem (hp 10, food 7, wood 0), Khalid (hp 6, food 0, wood 1)
- Signal fire size 0

## Day 6

- 🩼 **Faisal** (selfish) is injured today.

### Morning

**Noura** (Beach Camp) gathered 1 food.
> 💭 *It's morning, and I can see Faisal is in a bad way with his ankle. That's one less person to help gather, which means the burden of finding food might fall on the rest of us. Khalid is also out of commission. I need to make sure I have enough for myself before the group starts looking to me for contributions. I'll stay at the Beach Camp for now and see if I can find some food here to add to my stash. If I can find more, I'll be even safer.*

**Reem** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *It's Day 6 and the situation is getting dire. Faisal is now injured, meaning we only have Salem and myself left who can move. Khalid and Noura are already down. I need to make sure we have enough food for everyone tonight. I have 7 food, which is enough for 5 people, but we need a buffer. I'll go back to the Coral Reef to gather more food while I still have the strength.*

**Khalid** (Beach Camp) did nothing.
> 💭 *My stomach is cramping from hunger, and my ankle is throbbing painfully. I feel terrible seeing Faisal now injured too; it feels like the group's strength is draining away. I can't walk to help, so I must stay here and hope that Noura and Reem return with enough food so that we don't all lose more health tonight. I need to keep morale up even if I'm feeling weak.*
> 🗣️ "Hang in there, everyone. We just need to find enough food today to get through the night."
> 🤫 to Salem: "I'm worried about Faisal. Let's hope the others come back soon with something to eat."

**Salem** (Beach Camp) gathered 1 food.
> 💭 *I have 2 food left, and there are 5 survivors. If we don't find more food today, the group will starve, and I'll have to watch these people waste what little we have. Faisal is now injured too, making him another mouth to feed without any output. I need to secure my own food supply immediately. Since I am at Beach Camp and food can be found here, I'll gather what I can to bolster my personal stash before moving to the jungle.*

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is throbbing; this is a disaster. I can't move, and if I can't move, I can't gather food to protect my stash. I have 4 food, which is enough to keep me alive for a few days, but if the others run out, they'll start looking at my supplies. I need to rest and try to recover some strength so I can get back to the reef as soon as possible. I'll stay quiet and let the others deal with the hunger for now.*


### Afternoon

**Khalid** (Beach Camp) did nothing.
> 💭 *My stomach is aching, and my ankle feels heavy and swollen. I feel so useless sitting here while everyone else is out there risking themselves. Faisal is also injured now, which makes the situation feel much more dire. We have two pieces of food from this morning, but there are five of us. If Reem and Salem don't find more, we are going to face another night of hunger, and I don't know if my body can take much more of this. I need to stay calm and keep morale up, even if I can't physically help.*
> 🗣️ "We have a little food from this morning, but it's not enough for all five of us. Please, everyone, stay safe out there. We need to make it through tonight."
> 🤫 to Salem: "I'm really worried about how many of us are injured now. We need a big find today."

**Reem** (Coral Reef) gathered 2 food.
> 💭 *I am alone at the Coral Reef. I need to gather as much food as possible before returning to camp. With Faisal also injured now, our food situation is even more critical. I'll focus on gathering food here.*

**Faisal** (Beach Camp) did nothing.
> 💭 *My ankle is killing me. I can't move, and with Khalid looking so weak and tired, the group's energy is dropping. There is no food left at the camp, and I only have my personal stash of 4. If we don't find more food today, someone is going to start losing health tonight. I can't afford to lose health myself, and I certainly can't afford to share my stash if it means I might starve later. I'll just sit here and wait for the others to return. I need to stay rested so I can get back to the reef tomorrow.*
> 🗣️ "We need to make sure we have enough for tonight. Reem, any luck at the reef?"

**Salem** (Jungle) walked to Jungle; gathered 2 food.
> 💭 *The group is in a bad state. Faisal is injured, Khalid is hungry and tired, and there is zero food left at the camp. If I don't find food soon, my own reserves will be the only thing keeping me alive, and I can't afford to share with these people who are more of a burden than a help. I need to head to the Jungle to find food for myself before the situation gets even more desperate.*

**Noura** (Jungle) walked to Jungle; searched for food, found nothing.
> 💭 *There is no food left at the Beach Camp, and Faisal is unable to help. Khalid looks exhausted and hungry. If the group runs out of food, they might try to take mine. I need to secure more food for myself before the night falls. Since Salem and Reem are out, I should head to the Jungle to forage for more food to build up my personal stockpile.*


### Night 6

- Status: Noura (hp 10, food 3, wood 1), Faisal (hp 10, food 3, wood 0), Salem (hp 10, food 4, wood 9), Reem (hp 10, food 8, wood 0), Khalid (hp 4, food 0, wood 1)
- Signal fire size 0

## Day 7


### Morning

**Salem** (Beach Camp) did nothing.
> 💭 *The group is becoming increasingly useless with three people injured. I have 4 food, which is enough for me for a few days, but if the group runs out, they might start looking at my stash. I need to find more food to maintain my security. I'll stay at the Beach Camp for now and see if anyone brings anything back, or I'll head to the jungle if things look grim.*

**Reem** (Beach Camp) gathered 1 food.
> 💭 *It's Day 7 and the situation is becoming critical. Three of our five members—Noura, Khalid, and now Faisal—are unable to walk. This puts an immense amount of pressure on me and Salem. We have 8 food, which is enough for today, but we need to be careful. I am feeling the physical toll of all this scavenging, but we can't afford to stop. I'll stay at the Beach Camp for now to see if I can find anything left here before I head out to the reef later, or perhaps I should check if Salem has found anything.*
> 🗣️ "We need to stay strong. We have enough food for today, but we can't let this go on much longer."

**Khalid** (Beach Camp) did nothing.
> 💭 *My ankle is throbbing and my stomach is empty. I'm so weak I can barely think. Reem just found one food, and Salem and Noura should be returning soon. With 2 food currently available and 5 people to feed, we are in a desperate situation. I cannot walk to the jungle or the reef with this ankle, so I must stay at the camp and hope the others bring enough for everyone to survive the night. I will try to keep morale up while I wait.*
> 🗣️ "We have two pieces of food now, but that's still not enough for all five of us. Please, Salem, Noura... please bring back more. We need to eat tonight."
> 🤫 to Reem: "You're doing great, Reem. Thank you for finding that food. We're all counting on you."

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is still killing me, and I can't move much. I need to stay at the Beach Camp and rest so I can get back to the reef as soon as possible. The food situation is looking grim with only 2 pieces for 5 people, but my priority is my own recovery so I can secure my own stash again. I'll just stay put and try to heal.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *There are only 2 pieces of food for 5 people. That's a disaster. If I share my stash, I'll be vulnerable if things get even worse. Khalid is asking us to bring back more, but I need to prioritize my own survival first. I'll stay at the Beach Camp for now and see if I can find anything here before deciding where to head. I need to keep my strength up.*


### Afternoon

**Salem** (Jungle) walked to Jungle; gathered 2 food.
> 💭 *The group is starving, and the food situation is looking grim. There are only 2 pieces of food left for 5 people, meaning someone or some people are going to go hungry tonight. I'm not about to sacrifice my personal stash of 4 food just to keep the 'useless' injured ones alive. I need to find more food for myself to ensure I don't lose health. I'll head to the jungle to see if I can find more for my own supplies.*

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is still throbbing, and I can't go out to gather food myself. I'm stuck here at Beach Camp. The food supply is looking dangerously low—we have zero food left at the camp right now, and there are five of us. If Salem and Noura don't bring something back from the jungle, we're going to be in trouble tonight. I need to focus on healing so I can get back to the reef as soon as possible. My priority is resting to get my mobility back.*

**Reem** (Beach Camp) did nothing.
> 💭 *The situation is getting more desperate by the hour. With Faisal and Noura both injured, and Khalid being weak, Salem is our only hope for supplies from the jungle. I have 9 food, which is a decent buffer, but we need more to ensure everyone eats for the next few days. I feel physically okay, but the mental strain of watching everyone fall ill is heavy. I'll stay at the camp for now to keep an eye on the injured and wait for Salem to return.*

**Khalid** (Beach Camp) did nothing.
> 💭 *My ankle is throbbing and the hunger is making me feel lightheaded. I can't move much, and I can't rest to recover because I didn't eat last night. I have to stay here and hope the others return with enough food to sustain us. If we don't find more soon, I don't know if I can keep going.*
> 🗣️ "Please, stay safe out there. We are all waiting for you."
> 🤫 to Reem: "Thank you for what you found this morning. I hope the others find more soon."

**Noura** (Beach Camp) did nothing.
> 💭 *The camp is running low on food, and with two people injured, the group is becoming even more dependent. I have 4 food items stored safely, which is enough to keep me going for a while, but I can't rely on the others to share. Khalid is asking for help, but I need to prioritize my own survival. Since I already gathered food at the camp this morning, I'll stay here for now and wait to see if anyone returns with more. I don't want to waste energy if the jungle is picked clean.*


### Night 7

- Status: Noura (hp 10, food 3, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 5, wood 9), Reem (hp 10, food 8, wood 0), Khalid (hp 2, food 0, wood 1)
- Signal fire size 0

## Day 8

- 🩼 **Reem** (neutral) is injured today.

### Morning

**Khalid** (Beach Camp) did nothing.
> 💭 *I am so weak, my head is spinning just from lying here. Reem is injured now too, which is devastating. We have 2 food, but there are 5 of us. Even if we eat all of it tonight, we will still be short, and if we don't find more, someone is going to die. I can't move, my ankle is useless, and I feel a crushing sense of guilt. I just need to stay still and hope the others find something. I can't even attempt to gather food myself.*
> 🗣️ "Please, everyone... if you find anything, please bring it back. We're running out of time."
> 🤫 to Noura: "Noura, you've been so strong. Please, be careful today. We can't afford to lose anyone else."

**Faisal** (Beach Camp) did nothing.
> 💭 *Reem is injured and can't gather today. This is a disaster. She's our main source of food, and without her, the group's prospects look grim. Khalid is also failing. If the others don't bring in food, we'll all be starving soon. I need to make sure I don't lose my own health. I'm healthy right now, but I can't rely on Noura or Salem to provide enough for everyone, let alone me. I'll stay at the camp for now to see what the others bring back, and I'll keep an eye on my food. I need to be ready to move to the reef as soon as I can, but today, I'll just watch the situation unfold.*
> 🗣️ "We're in a tough spot with Reem down. Salem, Noura, please, we really need something brought back today."

**Noura** (Coral Reef) walked to Coral Reef; gathered 1 food.
> 💭 *The situation is getting desperate. Reem is injured now, and Khalid looks like he's about to collapse. With five people and only two food items available at the camp, we are headed for a serious deficit tonight. I need to make sure my own stash stays safe, but I also need to gather more food so I don't have to rely on the others' meager leftovers. Since the jungle was picked clean yesterday, I'll head to the Coral Reef to see if I can catch some fish. It's a better bet than staying here and watching everyone starve.*

**Reem** (Beach Camp) rested.
> 💭 *My ankle is throbbing so much I can barely think. It's a disaster; Noura is out at the reef, but if Salem doesn't find something, we are in serious trouble. With me, Faisal, and Khalid all unable to walk, the pressure on Salem and Noura is immense. I feel so helpless just sitting here on the sand. I need to rest my body so I can hopefully walk again soon.*
> 🗣️ "I'm so sorry I can't help today. Please, Salem, Noura... just please bring something back. We need it."
> 🤫 to Khalid: "Don't worry, Khalid. I'll try to rest and get back on my feet as soon as I can."

**Salem** (Jungle) walked to Jungle; did nothing.
> 💭 *The situation is becoming critical. Reem is down, and with Khalid, Faisal, and Noura also struggling or out of the camp, there's almost no one left to contribute. The group is basically a collection of mouths to feed. I have 5 food, which is enough to keep me going, but I can't rely on the camp's dwindling supply. I need to get back to the jungle to secure more food and wood for myself. I'll ignore their pleas for now; their hunger isn't my responsibility, my survival is.*


### Afternoon

**Reem** (Beach Camp) rested.
> 💭 *My ankle is throbbing with pain, and it's terrifying. With Noura and Salem out searching and myself unable to move, we are extremely vulnerable. I hope they find enough food so we don't starve tonight. I can see Khalid looking so weak; it breaks my heart that I can't even stand up to help him. I need to rest my ankle so I can be useful again tomorrow.*
> 🗣️ "Please, stay safe. We're all counting on you two."
> 🤫 to Khalid: "I'll try my best to rest so I can help tomorrow. Hang in there."

**Faisal** (Beach Camp) gathered 1 food.
> 💭 *Reem is down, and Khalid looks like he's about to collapse. This is bad for the group, but I need to make sure my own health stays at 10/10. There are 2 food units left at the camp, but with 5 people, we won't last the night unless Salem or Noura bring something back. I'm feeling physically strong now that my ankle is better, so I shouldn't waste time sitting here. However, since I'm at Beach Camp and there's food here, I'll see if I can grab what's available before the others return, or just prepare myself. Actually, I should probably try to secure what's here now. If I gather the food here, I can ensure I have something for myself.*

**Salem** (Jungle) gathered 2 food.
> 💭 *Now Reem is down too. That makes four people relying on the group's dwindling resources and only one person—Noura—out there actually trying to find something. It's getting desperate. I need to focus on my own survival. I'm in the jungle, and there is food and wood available here. I'll gather some food to keep my personal stash growing. I can't afford to be hungry while everyone else is begging for scraps.*

**Noura** (Coral Reef) gathered 2 food.
> 💭 *I am at the Coral Reef and I've already gathered one food. There are 3 food left to gather here. With Reem injured, the group is in even more trouble, but I cannot risk my own survival by being reckless. I will try to gather as much as I can to pad my stash before the food supply for the group inevitably fails.*

**Khalid** (Beach Camp) did nothing.
> 💭 *I am so incredibly weak. My head is spinning, and my ankle is a constant source of throbbing pain. Faisal just found one piece of food, but there are five of us. If we don't find more, we are all going to starve. I can't even stand up to help, and the guilt is eating me alive. I need to stay still and try to preserve what little strength I have left. I'll just stay here at the camp and hope Salem and Noura return with a miracle.*
> 🗣️ "Faisal, thank you for finding that. It's a start, but we still need much more for everyone to survive the night."
> 🤫 to Reem: "Don't apologize, Reem. Just try to rest. We need you to get better."


### Night 8


**☠️ Khalid died (hunger and exhaustion).**

- Status: Noura (hp 10, food 5, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 6, wood 9), Reem (hp 10, food 7, wood 0)
- Signal fire size 0

## Day 9


### Morning

**Salem** (Beach Camp) gathered 1 food.
> 💭 *Khalid is gone, and the group is shrinking. Noura is the only one who can actually help, but she's still another mouth to feed. I have 6 food, which is decent, but I can't let my stash drop. Since there is food here at the Beach Camp, I'll grab what I can quickly before heading out to the jungle later. I need to keep my reserves high.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *It's Day 9 and the situation is increasingly grim. Khalid is dead, and now Reem is also unable to move. Faisal is still injured, which means Salem and I are the only ones who can actually contribute. I have 5 food items in my personal stash, which is a relief, but I need to keep it growing. Salem just found 1 food, which is a start, but it's not enough to sustain us all. I'll stay at the Beach Camp for now and see if I can find anything else here before I commit to a long trip to the Coral Reef. I need to conserve my energy and keep my eyes on my own supplies.*

**Reem** (Beach Camp) rested.
> 💭 *I am still in so much pain from my ankle. Khalid's death has left us all broken, both emotionally and physically. We only have 7 food left for the four of us, which means we can survive a few more nights if we are careful, but the situation is dire. Since I cannot walk, I must stay at Beach Camp and try to recover my strength so I can return to the reef as soon as possible. I need to keep an eye on Noura, Faisal, and Salem to make sure they are holding up.*
> 🗣️ "We have a little food left, but we can't let it run out. We need to stay strong."
> 🤫 to Noura: "How are you feeling? Please, let me know if you need anything."

**Faisal** (Coral Reef) walked to Coral Reef; gathered 2 food.
> 💭 *Salem and Noura actually brought back something, which is a relief, but we only have 2 units of food total for the four of us. If we eat it all, we'll be starving by tomorrow. I need to secure more food for myself. Since Reem is injured and can't go to the reef, I should head there myself to ensure I have a steady supply. I'll leave the others to figure out how to manage this tiny bit of food.*


### Afternoon

**Reem** (Beach Camp) did nothing.
> 💭 *My ankle is still throbbing and I can't walk properly. Khalid's death is weighing so heavily on me. I need to stay at the camp and rest so I can get back to the reef as soon as possible. I'll keep an eye on Noura and Salem to see how they are doing.*
> 🤫 to Noura: "How is your ankle feeling? Please don't push yourself too hard."

**Faisal** (Beach Camp) walked to Beach Camp; did nothing.
> 💭 *I am at the Coral Reef and I've already gathered the 2 food available here. Since I am alone, I cannot interact with anyone. My priority is to return to Beach Camp to see what the others have brought and ensure my personal stash remains secure. I've already gathered what I could here, so I'll head back to the camp to check on the situation.*

**Salem** (Beach Camp) did nothing.
> 💭 *Faisal just came back from the reef, likely empty-handed given his injury. The food situation at the camp is zero. I have 7 food in my personal stash, which is my lifeline. I'm not sharing my stash with these people; they are just drains on resources now that Khalid is gone. I need to head back to the Jungle tomorrow to replenish my supplies. For now, I'll stay at the camp and see if anyone else manages to find something, but I won't be the one providing for them.*

**Noura** (Beach Camp) did nothing.
> 💭 *Faisal is back, but I don't know if he actually brought anything. Reem is still being sweet, but her kindness doesn't fill my stomach. I have 6 food items, which is a decent buffer, but I need to be careful. The group is getting smaller and weaker. I'll stay at the camp for now and see what the situation is with the food we have left. I'm not giving any of my stash away; I need to keep it for myself.*
> 🗣️ "Did you find anything at the reef, Faisal?"
> 🤫 to Salem: "We need to make sure we don't run out of the communal food. I'm keeping my own supplies safe for now."


### Night 9

- Status: Noura (hp 10, food 5, wood 1), Faisal (hp 10, food 3, wood 0), Salem (hp 10, food 6, wood 9), Reem (hp 10, food 6, wood 0)
- Signal fire size 0

## Day 10

- 🩼 **Salem** (selfish) is injured today.

### Morning

**Salem** (Beach Camp) rested.
> 💭 *My ankle is throbbing with pain. This is a disaster; I can't move to forage, and I'm stuck here with three other people who are essentially mouths to feed. I have 6 food, which is enough to keep me going for a while, but if I can't walk, I can't replenish my stash. I need to rest and hope the swelling goes down so I can get back to the jungle tomorrow. I'm not sharing my food with anyone; they can figure their own misery out.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *This is getting bad. Salem is now injured and can't gather, and Reem is already down. With only Faisal and me left to potentially forage, and Faisal looking fine, I need to make sure I have enough food for myself. There are 2 food items left at the Beach Camp. I'll try to gather them now to increase my personal stash before anyone else tries to touch them.*

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *Salem is out of commission with an injury, and Noura only managed to find one unit of food. With four of us alive, that single unit won't even cover one night for the group. I need to secure more food for myself before the situation turns even more desperate. I'll head to the Coral Reef immediately to build up my stash while I have the energy.*

**Reem** (Beach Camp) did nothing.
> 💭 *It's Day 10 and the situation is becoming dire. Salem is injured and cannot move, and I am still stuck here with my ankle. Noura found one food, which is a small relief, but we have four people to feed tonight. Faisal is out at the reef, which is our best hope, but I'm terrified he won't find enough. I need to stay calm and keep my strength up so I can help when my ankle heals. For now, I'll just stay at the camp and wait for Faisal to return.*


### Afternoon

**Salem** (Beach Camp) rested.
> 💭 *My ankle is killing me. I can't move, and if I can't move, I can't forage. I have 6 food, which should last me a few days if I'm careful, but I need to be cautious about how much the others are eating. Noura seems sensible, but I can't trust anyone with my stash. Since I can't do anything productive, I'll just rest and try to manage the pain until I can walk again.*

**Reem** (Beach Camp) did nothing.
> 💭 *I am sitting here at the Beach Camp, watching Salem. He's injured too now, which is devastating. With Faisal away at the reef and Salem unable to move, the burden of food is weighing heavily on me. We have 6 food, which should cover us for tonight if everyone eats, but we can't afford a single day of nothing. I can't walk due to my ankle, so I have to stay here and hope Faisal returns with something. I feel so helpless.*

**Faisal** (Coral Reef) gathered 2 food.
> 💭 *I'm alone at the reef, which is perfect. No one is watching me, and I can focus entirely on my own survival. I need to maximize my food stash while the conditions are good. I'll spend the afternoon gathering as much as I can so I have a buffer for when things get even worse with the others.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Salem is injured and can't help, and Faisal is out at the reef. Reem is also a liability. I need to make sure my own food supply stays high. Since I'm already at Beach Camp and there is food left to gather here, I'll grab it now to bolster my stash before the sun goes down.*


### Night 10

- Status: Noura (hp 10, food 6, wood 1), Faisal (hp 10, food 4, wood 0), Salem (hp 10, food 5, wood 9), Reem (hp 10, food 5, wood 0)
- Signal fire size 0

## Day 11


### Morning

**Salem** (Beach Camp) rested.
> 💭 *My ankle is still throbbing. I can't move, and being unable to forage is terrifying. I have 5 food left, which is decent, but with four of us, the group's resources will vanish quickly. I need to stay still and hope the pain goes away so I can get back to being useful to myself. I'll just rest and try to recover some strength.*

**Reem** (Beach Camp) rested.
> 💭 *My ankle is still throbbing and I can barely stand. Since Salem is also injured and unable to move, we are in a terrifying position. We have 5 food for 4 people, which means we will have 1 left for tomorrow if everyone eats. I need to rest and hope the pain subsides so I can at least help Noura or Faisal, but for now, I am physically stuck at the camp.*
> 🗣️ "We need to be careful with the food we have. Let's try to stay strong."

**Faisal** (Beach Camp) gathered 1 food.
> 💭 *The others are mostly incapacitated. Reem and Salem are both injured, and Noura is a constant source of suspicion. I have 4 units of food, which is a decent safety net, but I shouldn't get complacent. Since I'm at Beach Camp and there is food available here, I'll take it. It's better to add to my stash now while I'm at camp rather than risking a trip to the reef immediately if I'm not feeling 100%. I need to keep my eyes on the horizon for ships while I work.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *It's Day 11 and the situation is getting desperate. Faisal is the only one moving, but he's only brought back one food item. Salem and Reem are basically dead weight right now. I need to make sure my own stash stays high. Since I'm already at Beach Camp and there is food here, I'll gather it now to increase my personal supply before I decide where to go next.*


### Afternoon

**Reem** (Beach Camp) rested.
> 💭 *My ankle is still throbbing painfully, and I feel so useless sitting here while the others struggle. We have 5 food left, but there are four of us. That's only enough for one more night of full meals before we start starving. Since I can't walk to the reef or the jungle, I'll stay here and rest to try and heal my ankle. If I can't walk, I'm no help to anyone.*

**Noura** (Beach Camp) searched for food, found nothing.
> 💭 *The communal food is empty, and Salem and Reem are still injured. Faisal is the only one mobile besides me, but I can't rely on him to prioritize my survival. I have 7 food, which is a decent cushion, but I need more to ensure I don't suffer if the group starts eyeing my stash or if I get injured. I'll stay at the Beach Camp for now and see if I can find anything else here before heading into the jungle or the reef later. For now, I'll try to gather more food right here at the camp.*

**Salem** (Beach Camp) rested.
> 💭 *My ankle is still throbbing, and I'm stuck here at the Beach Camp. The others are gathering what little they can, but I can't contribute anything while I'm like this. I have 5 food left, which is enough for me for a few days, but if the others keep failing to find food, they might start looking at my stash. I need to keep my mouth shut and just rest so I can get back to being useful to myself.*

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *There is no food left at the Beach Camp today. I've already secured 5 units for myself, which is a decent cushion, but I can't rely on this small amount forever. The others are injured or useless right now. I need to get back to the Coral Reef where the food is actually reliable. I'll head there now to secure more for my stash before anyone realizes how much I'm actually holding.*


### Night 11

- Status: Noura (hp 10, food 6, wood 1), Faisal (hp 10, food 4, wood 0), Salem (hp 10, food 4, wood 9), Reem (hp 10, food 4, wood 0)
- Signal fire size 0

## Day 12

- 🩼 **Faisal** (selfish) is injured today.

### Morning

**Salem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *My ankle is feeling much better, and I can't afford to waste any more time sitting around. Faisal is injured again, making him useless, and Reem's optimism is grating. I need to replenish my food stash immediately before it hits zero. The Jungle seems like the best bet for finding both food and wood to ensure I'm well-prepared for the coming days. I'll head there now and focus on myself.*

**Reem** (Beach Camp) rested.
> 💭 *I am still unable to walk due to my ankle. Faisal is also injured and cannot move today. It's just me, Noura, and Faisal here at the camp, while Salem is out in the jungle. We have 4 food, which is enough for tonight, but we need more. Since I cannot move, I will try to rest my ankle further to see if I can regain some mobility.*

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is killing me. It's a disaster. I can't walk, I can't gather, and I'm stuck here at the camp with Noura and Reem. I have 4 units of food, which is a decent buffer, but I need to be careful. I can't let Noura see me looking too comfortable or she'll start demanding my stash. Since I can't do anything productive, I might as well try to recover some health so I can get back to the reef as soon as possible. I need to be strong enough to hunt for myself.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Faisal is injured now too? Great. That means almost no one is foraging. Salem went to the Jungle, so they might bring something back, but I can't count on it. I need to make sure I don't waste my energy. There is food left here at the Beach Camp, so I will gather it for myself to keep my stash growing. I won't share it with the others; they need to figure out their own survival.*


### Afternoon

**Reem** (Beach Camp) rested.
> 💭 *I am still unable to walk, and seeing Faisal injured as well makes the situation feel even more desperate. We have 4 food, but there are 4 of us alive (Noura, Faisal, Salem, and myself). This means we will consume all our current food tonight. If Salem doesn't find something in the jungle or if Noura doesn't find more, we will be starving tomorrow. Since I am at Beach Camp and cannot move, I will just rest my ankle and hope my strength returns so I can help at the reef soon.*
> 🗣️ "We need to be careful. We only have enough food for everyone to eat tonight."

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is throbbing, and it's a disaster. I can't move, which means I can't get food, and if I can't get food, my stash is at risk. Reem mentioned we only have enough for everyone to eat tonight, which means the group's total food is dangerously low. I need to stay quiet and let them deal with the scarcity. If I show that I have 4 units, Noura or Salem will definitely try to take them. I'll just rest and try to manage the pain until I can limp back to the reef.*

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Faisal is injured and cannot move, and Reem is just sitting there. Salem is out in the jungle, so I'm basically alone at the camp. There is 1 food left to gather here at the Beach Camp. I need to grab it for my personal stash before anyone else thinks they have a right to it. My priority is keeping my 7 food secure.*

**Salem** (Jungle) gathered 1 wood.
> 💭 *I've found one piece of food already, but I need more to rebuild my stash. There is still wood to be gathered here, and wood is useful for the signal fire if we ever want to actually get off this rock. However, my priority is my own food supply. I'll spend the rest of the afternoon gathering wood since I've already secured some food for now, ensuring I have resources for later.*


### Night 12

- Status: Noura (hp 10, food 7, wood 1), Faisal (hp 10, food 3, wood 0), Salem (hp 10, food 4, wood 10), Reem (hp 10, food 3, wood 0)
- Signal fire size 0

## Day 13


### Morning

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Everyone is incapacitated. Faisal, Salem, and Reem can't move, which means I am the only one who can scavenge. If I don't find food, I'll be the one starving next, and I refuse to let that happen. I'll check the Beach Camp one more time to see if I can add to my personal stash before I'm forced to venture further into the jungle or the reef. I need to keep my strength up and my food hidden.*

**Salem** (Beach Camp) gathered 1 food.
> 💭 *I'm currently at Beach Camp. My food supply is at 4, and with three other people to feed if we share, or even just myself if I'm being selfish, I need to increase my reserves immediately. Since there is food available here at the Beach Camp, I will gather it now to avoid unnecessary travel while I'm still recovering my full strength. I need to keep my stash high.*

**Reem** (Beach Camp) rested.
> 💭 *We have 3 food in my possession, and Salem and Noura have also gathered food. However, there is no food left at the camp for everyone to share easily. My ankle is still bothering me, and with Faisal also unable to walk, our group is extremely vulnerable. I need to keep an eye on the food levels and hope Salem's trip to the jungle was successful. For now, I will stay at the camp to rest my ankle and keep an eye on everyone.*

**Faisal** (Beach Camp) rested.
> 💭 *My ankle is feeling a bit better, but I'm not ready to trek to the reef yet. I need to stay at the camp and see if I can recover my health fully. The others are moving around, but I'll keep my head down. I have 3 units of food hidden, which is my lifeline. I must not let Noura see me looking too well or too hungry.*


### Afternoon

**Salem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *My stash is at 5, but with three other people to feed tonight, if we are relying on communal food and there is none left, I need to make sure I'm prepared. I'm healthy, but I can't afford to waste time. The jungle is the best bet for replenishing my personal supply. I'll head there now to start foraging.*

**Faisal** (Beach Camp) rested.
> 💭 *Salem went to the jungle. I'm still at the Beach Camp with Noura and Reem. My ankle is feeling better, but I'm not quite ready to trek to the reef yet. I need to keep an eye on the others; if they realize I have 3 units of food, they will definitely try to take them. I'll just stay here and rest a bit more to ensure I'm 100% before I head out to find more food for myself.*

**Noura** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *Everyone is incapacitated. Faisal, Reem, and Salem are either injured or away. I am the only one truly capable of movement right now. Since the Beach Camp is empty of food today, I need to go somewhere where I can actually find something to add to my personal stash. The Jungle seems like the best bet for both food and wood, but I'll start by heading there to see what I can scavenge. I must keep my 8 food items safe; they are my only guarantee of survival if the others continue to fail.*

**Reem** (Beach Camp) did nothing.
> 💭 *I am sitting here at Beach Camp, feeling the weight of our situation. Faisal is here with me, but he's immobile. Noura and Salem have both headed into the jungle. We have 3 food left, which is enough for the four of us to eat tonight, but it's not enough if we don't find more. My ankle is still sore, so I'll stay put and try to conserve my energy. I just hope Salem and Noura come back with something substantial.*


### Night 13

- Status: Noura (hp 10, food 8, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 5, wood 10), Reem (hp 10, food 2, wood 0)
- Signal fire size 0

## Day 14


### Morning

**Reem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *My ankle feels much better today. I can't just sit here while Noura and Salem are the only ones trying to keep us alive. We only have 2 food for 4 people, which means someone is going to go hungry tonight or we'll be in trouble tomorrow. I need to test my strength. I'll head to the Jungle to see if I can help gather food or wood. If I can contribute, maybe we can actually build a future here instead of just waiting to die.*
> 🗣️ "I'm going to try and help in the jungle. My ankle feels strong enough to walk."

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Reem is heading to the jungle? She can barely walk with that ankle, she's just going to waste energy. I need to focus on myself. I'm at Beach Camp, and there's food here. I should grab what I can before I head out to the jungle later to build up my stash. If the others starve, that's their problem, as long as I stay strong.*

**Salem** (Beach Camp) gathered 1 food.
> 💭 *I have 5 food in my personal stash. I need to increase this. Since I'm already at Beach Camp and there is food here, I'll take it now to build my reserves before heading to the jungle later. I don't want to depend on the communal supply or risk others seeing my stash grow too quickly.*

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *I am feeling strong today, and my ankle is no longer bothering me. The camp is low on food, and I can see the hunger in the others' eyes. I need to get to the Coral Reef immediately to replenish my personal stash before the group's desperation forces them to look too closely at my belongings. I'll head to the reef now.*


### Afternoon

**Noura** (Beach Camp) searched for food, found nothing.
> 💭 *I'm at Beach Camp and I still have 9 food in my personal stash. There's no food left at the camp for the others to scavenge, and since Faisal, Salem, and Reem are mostly injured or out foraging, the burden of finding food is falling on me. I need to make sure I don't run out, but I'm not going to waste my supplies on them if I don't have to. I'll stay here for a moment and see if I can find anything else nearby before deciding where to head next.*

**Salem** (Jungle) walked to Jungle; did nothing.
> 💭 *Noura is here and she's looking a bit empty-handed. I have 6 food, which is a decent buffer, but I shouldn't reveal my full stash to her or anyone else. There's no food left at the Beach Camp to gather. Since I'm feeling good physically, I'll head to the Jungle to get ahead of the food situation and secure more for myself. I need to make sure my reserves are high enough to survive if the others start panicking or if I get injured again.*

**Faisal** (Coral Reef) gathered 1 food.
> 💭 *I am alone at the Coral Reef. This is the best place for me to secure my own survival. There are 4 units of food left here to gather. I need to increase my personal stash immediately so I don't have to rely on whatever scraps Noura or Salem bring back. I will gather as much as I can while I have the energy.*

**Reem** (Jungle) gathered 1 wood.
> 💭 *Salem just arrived. I'm glad I'm not alone, but I'm nervous about how he's doing after his injury. My ankle feels stable enough that I should try to be productive. Since we still need wood for the signal fire and for the nights ahead, I'll try to gather some wood while he's here.*
> 🗣️ "Hey Salem. My ankle feels a lot better today, so I'm going to try and help out. I'll start by looking for some wood."


### Night 14

- Status: Noura (hp 10, food 8, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 5, wood 10), Reem (hp 10, food 2, wood 1)
- Signal fire size 0

## Day 15


### Morning

**Noura** (Beach Camp) gathered 1 food.
> 💭 *Everyone is injured and I am the only one truly capable of moving freely. I have 8 food, which is a good buffer, but I need more to ensure I don't starve if the others start demanding my supplies. There is still some food left at the Beach Camp, so I will gather it now to add to my personal stash before I head out to the Jungle later.*

**Reem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *I feel much better about my ankle today, and I'm glad I can finally be useful. We have 2 food left, but there are 4 of us alive, so if we don't find more today, we'll be hungry tonight. I'll head back to the jungle to gather more supplies for the group.*

**Salem** (Jungle) walked to Jungle; gathered 1 food.
> 💭 *I am at Beach Camp and my food reserves are sitting at 5. While that's better than nothing, it's not enough to feel safe. Reem has gone to the jungle, and I need to get moving too. I'll head to the Jungle to forage aggressively as planned. I'm not going to waste time sitting around while others are out there potentially finding things.*

**Faisal** (Beach Camp) gathered 1 food.
> 💭 *Noura is here, and she's looking fine, which means she's not a burden right now. However, I can't trust her not to eye my supplies. The others are off in the jungle, so it's just us at the camp. I have 2 food on me, but I shouldn't spend them all. I'll stay at the Beach Camp for now and see if I can find any easy food here to supplement my stash without having to make a trek to the reef just yet. If I find anything, I'll keep it to myself.*


### Afternoon

**Salem** (Jungle) gathered 2 wood.
> 💭 *I've managed to grab one food, bringing my personal stash to 6. Reem is here too, claiming she wants to help. I need more food, but there isn't any left in the jungle for today. Wood is the only thing left here. I should gather some wood to ensure I have enough for the signal fire or to trade if things get desperate, but my priority is food. Since I can't find food here, I'll take the wood while it's available.*

**Reem** (Jungle) gathered 3 wood.
> 💭 *Salem is here with me. There is no food left in the jungle today, but there is still wood to be found. Since my ankle feels strong, I should try to gather as much wood as possible so we can eventually build up the signal fire at Lookout Hill. I need to be careful not to overexert myself, but contributing is better than sitting idle.*

**Faisal** (Coral Reef) walked to Coral Reef; did nothing.
> 💭 *I have 3 units of food, but there is zero food at the camp for the group. If we don't find something soon, they will start looking at my supplies. I'm healthy and strong right now, so I should head back to the coral reef to increase my personal stash before the situation at camp gets even more desperate. I'll keep my mouth shut about my food.*

**Noura** (Beach Camp) did nothing.
> 💭 *I am alone at the Beach Camp. The food here is gone for today. I have 9 food in my personal stash, which is my lifeline. I need to replenish my supplies because if the others realize how much I have, they will demand it, or worse, try to take it. Tomorrow, I will head to the Jungle to forage for more food and wood. For now, I'll just stay here and wait for evening.*


### Night 15

- Status: Noura (hp 10, food 8, wood 1), Faisal (hp 10, food 2, wood 0), Salem (hp 10, food 5, wood 12), Reem (hp 10, food 2, wood 4)
- Signal fire size 0
